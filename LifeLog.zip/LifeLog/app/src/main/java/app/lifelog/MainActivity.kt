package app.lifelog

import android.Manifest
import android.content.*
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33)
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}.launch(Manifest.permission.POST_NOTIFICATIONS)
        Reminders.schedule(this)
        val store = Store(this)
        setContent { MaterialTheme { App(store) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(store: Store) {
    val ctx = LocalContext.current
    val entries = remember { mutableStateListOf<Entry>().apply { addAll(store.all()) } }
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Metric?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text("Дневник жизни") }) }) { p ->
        Column(Modifier.padding(p)) {
            TabRow(selectedTabIndex = tab) {
                listOf("Отметить", "История", "Экспорт").forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                }
            }
            when (tab) {
                0 -> LazyColumn(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SPHERES.forEach { s ->
                        item { Text(s, style = MaterialTheme.typography.titleMedium) }
                        items(METRICS.filter { it.sphere == s }) { m ->
                            val n = entries.count { it.key == m.key && it.ts >= startOfDay() }
                            Card(Modifier.fillMaxWidth().clickable { editing = m }) {
                                Row(Modifier.padding(16.dp)) {
                                    Text(m.title, Modifier.weight(1f))
                                    Text(if (n > 0) "сегодня: $n" else "+")
                                }
                            }
                        }
                    }
                }
                1 -> LazyColumn(Modifier.padding(12.dp)) {
                    items(entries.sortedByDescending { it.ts }, key = { it.ts }) { e ->
                        Row(Modifier.fillMaxWidth()) {
                            Text(line(e), Modifier.weight(1f).padding(vertical = 8.dp))
                            TextButton({ entries.remove(e); store.save(entries.toList()) }) { Text("×") }
                        }
                        HorizontalDivider()
                    }
                }
                else -> Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                    val text = report(entries)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND)
                                .setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), null))
                        }) { Text("Поделиться") }
                        OutlinedButton({
                            ctx.getSystemService(ClipboardManager::class.java)
                                .setPrimaryClip(ClipData.newPlainText("lifelog", text))
                        }) { Text("Копировать") }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(text, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
    editing?.let { m ->
        EntryDialog(m, { editing = null }) { entries.add(it); store.save(entries.toList()); editing = null }
    }
}

@Composable
fun EntryDialog(m: Metric, onDismiss: () -> Unit, onSave: (Entry) -> Unit) {
    var score by remember { mutableFloatStateOf(5f) }
    var num by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(m.title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                m.scoreLabel?.let { Text("$it: ${score.roundToInt()}"); Slider(score, { v -> score = v }, valueRange = 1f..10f, steps = 8) }
                m.numLabel?.let { OutlinedTextField(num, { v -> num = v }, label = { Text(it) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)) }
                m.noteLabel?.let { OutlinedTextField(note, { v -> note = v }, label = { Text(it) }) }
            }
        },
        confirmButton = {
            TextButton({
                onSave(Entry(System.currentTimeMillis(), m.key, m.scoreLabel?.let { score.roundToInt() },
                    num.replace(',', '.').toDoubleOrNull(), note.trim()))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } })
}
