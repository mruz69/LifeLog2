package app.lifelog

import android.app.*
import android.content.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Metric(val key: String, val sphere: String, val title: String,
                  val scoreLabel: String? = null, val numLabel: String? = null, val noteLabel: String? = null)

data class Entry(val ts: Long, val key: String, val score: Int?, val num: Double?, val note: String)

val SPHERES = listOf("Здоровье", "Отношения", "Работа", "Развитие")  // порядок = ваши приоритеты

val METRICS = listOf(
    Metric("sleep", "Здоровье", "Сон", "Как выспался", "Часов сна", "Лёг/встал (напр. 23:30–07:00)"),
    Metric("activity", "Здоровье", "Спорт и активность", null, "Минут активности", "Тренировка / шаги"),
    Metric("feeling", "Здоровье", "Самочувствие", "Энергия", "Вес, кг", "Боль, давление, симптомы"),
    Metric("social", "Отношения", "Эмоции после общения", "1 — выматывает, 10 — заряжает", null, "С кем / что было"),
    Metric("career", "Работа", "Прогресс к карьерным целям", "Прогресс", null, "Проект / обучение"),
    Metric("stress", "Работа", "Стресс", "Уровень стресса (10 — максимум)", null, "Что вызвало"),
    Metric("fatigue", "Работа", "Усталость от работы", "Усталость (10 — максимум)", null, null),
    Metric("learning", "Развитие", "Учёба и развитие", null, "Минут", "Книга, курс, навык"),
    Metric("mood", "Развитие", "Настроение дня", "Настроение", null, "Заметка"),
)

class Store(ctx: Context) {
    private val f = File(ctx.filesDir, "entries.json")
    fun all(): List<Entry> = if (!f.exists()) emptyList() else JSONArray(f.readText()).let { a ->
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Entry(o.getLong("ts"), o.getString("k"), if (o.has("s")) o.getInt("s") else null,
                if (o.has("n")) o.getDouble("n") else null, o.optString("t"))
        }
    }
    fun save(list: List<Entry>) {
        val a = JSONArray()
        list.forEach { e ->
            a.put(JSONObject().put("ts", e.ts).put("k", e.key).put("t", e.note)
                .apply { e.score?.let { put("s", it) }; e.num?.let { put("n", it) } })
        }
        f.writeText(a.toString())
    }
}

fun startOfDay(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun line(e: Entry): String {
    val m = METRICS.firstOrNull { it.key == e.key }
    return listOfNotNull(
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(e.ts)),
        m?.title ?: e.key, e.score?.let { "оценка=$it" }, e.num?.let { "${m?.numLabel}=$it" }, e.note.ifBlank { null }
    ).joinToString(" | ")
}

fun report(es: List<Entry>): String {
    val since = System.currentTimeMillis() - 30 * 86400000L
    return buildString {
        appendLine("Мой дневник жизни за 30 дней. Шкалы 1–10 (стресс и усталость: 10 = максимум; общение: 1 = выматывает, 10 = заряжает).")
        appendLine("Приоритеты сфер: 1) здоровье 2) отношения 3) работа 4) развитие.")
        appendLine("Проанализируй: закономерности, связи между сферами (например сон → настроение → стресс), тревожные тенденции, и дай конкретные советы на неделю.")
        appendLine()
        es.filter { it.ts >= since }.sortedBy { it.ts }.forEach { appendLine(line(it)) }
    }
}

object Reminders {
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        listOf(Triple(1, 8, "Доброе утро! Отметь сон и самочувствие"),
            Triple(2, 21, "Вечер: как прошёл день? Отметь настроение и стресс")).forEach { (id, h, text) ->
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
                if (timeInMillis < System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val pi = PendingIntent.getBroadcast(c, id,
                Intent(c, AlarmReceiver::class.java).putExtra("t", text).putExtra("id", id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) { Reminders.schedule(c); return }
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("daily", "Напоминания", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(i.getIntExtra("id", 0), Notification.Builder(c, "daily")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Дневник жизни")
            .setContentText(i.getStringExtra("t")).setContentIntent(pi).setAutoCancel(true).build())
    }
}
